package com.oatrice.internet_speed_testing;

import android.support.v7.app.AppCompatActivity;

public class MainKotlinActivity extends AppCompatActivity {

}
